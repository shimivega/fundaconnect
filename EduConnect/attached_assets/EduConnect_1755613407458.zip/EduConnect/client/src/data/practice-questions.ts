export const practiceQuestions = [
  // Mathematics Grade 7
  {
    subject: "Mathematics",
    grade: "Grade 7",
    questions: [
      {
        language: "English",
        question: "What is 12 × 8?",
        options: ["90", "96", "100", "88"],
        answer: "96"
      },
      {
        language: "Afrikaans",
        question: "Wat is 12 × 8?",
        options: ["90", "96", "100", "88"],
        answer: "96"
      },
      {
        language: "IsiZulu",
        question: "Yini 12 × 8?",
        options: ["90", "96", "100", "88"],
        answer: "96"
      },
      {
        language: "IsiXhosa",
        question: "Yintoni 12 × 8?",
        options: ["90", "96", "100", "88"],
        answer: "96"
      },
      {
        language: "English",
        question: "What is 25% of 80?",
        options: ["15", "20", "25", "30"],
        answer: "20"
      },
      {
        language: "Afrikaans",
        question: "Wat is 25% van 80?",
        options: ["15", "20", "25", "30"],
        answer: "20"
      }
    ]
  },

  // English Grade 7
  {
    subject: "English",
    grade: "Grade 7",
    questions: [
      {
        language: "English",
        question: "Choose the correct past tense: I ____ to the park yesterday.",
        options: ["go", "went", "gone", "going"],
        answer: "went"
      },
      {
        language: "Afrikaans",
        question: "Kies die korrekte verlede tyd: Ek ____ gister park toe.",
        options: ["gaan", "het gegaan", "gegaan", "gaande"],
        answer: "het gegaan"
      },
      {
        language: "English",
        question: "What is the plural of 'child'?",
        options: ["childs", "children", "childes", "child"],
        answer: "children"
      }
    ]
  },

  // Science Grade 8
  {
    subject: "Science",
    grade: "Grade 8",
    questions: [
      {
        language: "English",
        question: "What is H2O commonly known as?",
        options: ["Oxygen", "Water", "Hydrogen", "Salt"],
        answer: "Water"
      },
      {
        language: "Afrikaans",
        question: "Wat is H2O algemeen bekend as?",
        options: ["Suurstof", "Water", "Waterstof", "Sout"],
        answer: "Water"
      },
      {
        language: "IsiZulu",
        question: "Yini i-H2O eyaziwa kakhulu?",
        options: ["Umoya-mpilo", "Amanzi", "I-Hydrogen", "Usawoti"],
        answer: "Amanzi"
      },
      {
        language: "IsiXhosa",
        question: "Yintoni i-H2O eyaziwa kakhulu?",
        options: ["Umoya-mpilo", "Amanzi", "I-Hydrogen", "Usawoti"],
        answer: "Amanzi"
      },
      {
        language: "English",
        question: "What process do plants use to make food?",
        options: ["Respiration", "Photosynthesis", "Digestion", "Circulation"],
        answer: "Photosynthesis"
      }
    ]
  },

  // History Grade 9
  {
    subject: "History",
    grade: "Grade 9",
    questions: [
      {
        language: "English",
        question: "Who was the first President of South Africa after 1994?",
        options: ["Nelson Mandela", "Thabo Mbeki", "F.W. de Klerk", "Cyril Ramaphosa"],
        answer: "Nelson Mandela"
      },
      {
        language: "Afrikaans",
        question: "Wie was die eerste president van Suid-Afrika ná 1994?",
        options: ["Nelson Mandela", "Thabo Mbeki", "F.W. de Klerk", "Cyril Ramaphosa"],
        answer: "Nelson Mandela"
      },
      {
        language: "IsiZulu",
        question: "Ubani uMongameli wokuqala waseNingizimu Afrika emva kuka-1994?",
        options: ["Nelson Mandela", "Thabo Mbeki", "F.W. de Klerk", "Cyril Ramaphosa"],
        answer: "Nelson Mandela"
      },
      {
        language: "IsiXhosa",
        question: "Ngubani uMongameli wokuqala waseMzantsi Afrika emva kuka-1994?",
        options: ["Nelson Mandela", "Thabo Mbeki", "F.W. de Klerk", "Cyril Ramaphosa"],
        answer: "Nelson Mandela"
      },
      {
        language: "English",
        question: "In which year did apartheid officially end in South Africa?",
        options: ["1990", "1994", "1996", "1999"],
        answer: "1994"
      }
    ]
  },

  // Mathematics Grade 8
  {
    subject: "Mathematics",
    grade: "Grade 8",
    questions: [
      {
        language: "English",
        question: "What is the square root of 64?",
        options: ["6", "7", "8", "9"],
        answer: "8"
      },
      {
        language: "Afrikaans",
        question: "Wat is die vierkantswortel van 64?",
        options: ["6", "7", "8", "9"],
        answer: "8"
      },
      {
        language: "English",
        question: "Solve for x: 2x + 5 = 15",
        options: ["3", "4", "5", "6"],
        answer: "5"
      }
    ]
  },

  // Science Grade 9
  {
    subject: "Science",
    grade: "Grade 9",
    questions: [
      {
        language: "English",
        question: "What is the chemical symbol for gold?",
        options: ["Go", "Gd", "Au", "Ag"],
        answer: "Au"
      },
      {
        language: "Afrikaans",
        question: "Wat is die chemiese simbool vir goud?",
        options: ["Go", "Gd", "Au", "Ag"],
        answer: "Au"
      },
      {
        language: "English",
        question: "Which planet is closest to the Sun?",
        options: ["Venus", "Earth", "Mercury", "Mars"],
        answer: "Mercury"
      }
    ]
  }
];
