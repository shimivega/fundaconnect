export const saEducationalResources = [
  {
    subject: "Mathematics",
    grades: Array.from({ length: 13 }, (_, i) => ({
      grade: `Grade ${i === 0 ? "R" : i}`,
      links: [
        { 
          name: "Textbooks", 
          url: `https://www.education.gov.za/Curriculum/Maths/Grade${i === 0 ? "R" : i}.pdf`,
          description: "Official curriculum textbooks"
        },
        { 
          name: "Past Exam Papers", 
          url: `https://www.education.gov.za/PastPapers/Mathematics/Grade${i === 0 ? "R" : i}`,
          description: "Previous years' examination papers"
        },
        { 
          name: "Online Practice", 
          url: `https://funda.co.za/maths/grade${i === 0 ? "R" : i}`,
          description: "Interactive practice exercises"
        }
      ]
    }))
  },
  {
    subject: "English",
    grades: Array.from({ length: 13 }, (_, i) => ({
      grade: `Grade ${i === 0 ? "R" : i}`,
      links: [
        { 
          name: "Textbooks", 
          url: `https://www.education.gov.za/Curriculum/English/Grade${i === 0 ? "R" : i}.pdf`,
          description: "English language curriculum materials"
        },
        { 
          name: "Past Exam Papers", 
          url: `https://www.education.gov.za/PastPapers/English/Grade${i === 0 ? "R" : i}`,
          description: "English examination papers"
        },
        { 
          name: "Reading Resources", 
          url: `https://funda.co.za/english/grade${i === 0 ? "R" : i}`,
          description: "Reading comprehension materials"
        }
      ]
    }))
  },
  {
    subject: "Afrikaans",
    grades: Array.from({ length: 13 }, (_, i) => ({
      grade: `Grade ${i === 0 ? "R" : i}`,
      links: [
        { 
          name: "Textbooks", 
          url: `https://www.education.gov.za/Curriculum/Afrikaans/Grade${i === 0 ? "R" : i}.pdf`,
          description: "Afrikaans language curriculum"
        },
        { 
          name: "Past Exam Papers", 
          url: `https://www.education.gov.za/PastPapers/Afrikaans/Grade${i === 0 ? "R" : i}`,
          description: "Afrikaans examination papers"
        },
        { 
          name: "Language Practice", 
          url: `https://funda.co.za/afrikaans/grade${i === 0 ? "R" : i}`,
          description: "Afrikaans language exercises"
        }
      ]
    }))
  },
  {
    subject: "IsiZulu",
    grades: Array.from({ length: 13 }, (_, i) => ({
      grade: `Grade ${i === 0 ? "R" : i}`,
      links: [
        { 
          name: "Textbooks", 
          url: `https://www.education.gov.za/Curriculum/IsiZulu/Grade${i === 0 ? "R" : i}.pdf`,
          description: "IsiZulu language curriculum"
        },
        { 
          name: "Past Exam Papers", 
          url: `https://www.education.gov.za/PastPapers/IsiZulu/Grade${i === 0 ? "R" : i}`,
          description: "IsiZulu examination papers"
        },
        { 
          name: "Cultural Resources", 
          url: `https://funda.co.za/isizulu/grade${i === 0 ? "R" : i}`,
          description: "IsiZulu cultural and language materials"
        }
      ]
    }))
  },
  {
    subject: "Science",
    grades: Array.from({ length: 13 }, (_, i) => ({
      grade: `Grade ${i === 0 ? "R" : i}`,
      links: [
        { 
          name: "Textbooks", 
          url: `https://www.education.gov.za/Curriculum/Science/Grade${i === 0 ? "R" : i}.pdf`,
          description: "Natural sciences curriculum"
        },
        { 
          name: "Past Exam Papers", 
          url: `https://www.education.gov.za/PastPapers/Science/Grade${i === 0 ? "R" : i}`,
          description: "Science examination papers"
        },
        { 
          name: "Virtual Labs", 
          url: `https://funda.co.za/science/grade${i === 0 ? "R" : i}`,
          description: "Interactive science experiments"
        }
      ]
    }))
  },
  {
    subject: "History",
    grades: Array.from({ length: 13 }, (_, i) => ({
      grade: `Grade ${i === 0 ? "R" : i}`,
      links: [
        { 
          name: "Textbooks", 
          url: `https://www.education.gov.za/Curriculum/History/Grade${i === 0 ? "R" : i}.pdf`,
          description: "South African history curriculum"
        },
        { 
          name: "Past Exam Papers", 
          url: `https://www.education.gov.za/PastPapers/History/Grade${i === 0 ? "R" : i}`,
          description: "History examination papers"
        },
        { 
          name: "Heritage Resources", 
          url: `https://funda.co.za/history/grade${i === 0 ? "R" : i}`,
          description: "South African heritage materials"
        }
      ]
    }))
  },
  {
    subject: "Geography",
    grades: Array.from({ length: 13 }, (_, i) => ({
      grade: `Grade ${i === 0 ? "R" : i}`,
      links: [
        { 
          name: "Textbooks", 
          url: `https://www.education.gov.za/Curriculum/Geography/Grade${i === 0 ? "R" : i}.pdf`,
          description: "Geography curriculum materials"
        },
        { 
          name: "Past Exam Papers", 
          url: `https://www.education.gov.za/PastPapers/Geography/Grade${i === 0 ? "R" : i}`,
          description: "Geography examination papers"
        },
        { 
          name: "Map Resources", 
          url: `https://funda.co.za/geography/grade${i === 0 ? "R" : i}`,
          description: "Interactive maps and geographical data"
        }
      ]
    }))
  },
  {
    subject: "Life Skills",
    grades: Array.from({ length: 13 }, (_, i) => ({
      grade: `Grade ${i === 0 ? "R" : i}`,
      links: [
        { 
          name: "Textbooks", 
          url: `https://www.education.gov.za/Curriculum/LifeSkills/Grade${i === 0 ? "R" : i}.pdf`,
          description: "Life orientation curriculum"
        },
        { 
          name: "Activity Guides", 
          url: `https://www.education.gov.za/Activities/LifeSkills/Grade${i === 0 ? "R" : i}`,
          description: "Practical life skills activities"
        },
        { 
          name: "Health Education", 
          url: `https://funda.co.za/lifeskills/grade${i === 0 ? "R" : i}`,
          description: "Health and wellness resources"
        }
      ]
    }))
  }
];

export const saLanguageResources = [
  {
    category: 'Rainbow Workbooks',
    description: 'Free downloadable PDFs across multiple languages for foundational learning',
    links: [
      { 
        grade: 'Grade R–2', 
        title: 'Rainbow Workbooks', 
        url: 'https://www.education.gov.za/2020WorkbooksTerm1and2.aspx',
        languages: ['All 11 official languages']
      },
    ],
  },
  {
    category: 'Graded Readers & Storybooks',
    description: 'Story titles available across all 11 official languages',
    links: [
      { 
        grade: 'Foundation Phase', 
        title: 'Graded Readers & Big Books', 
        url: 'https://www.education.gov.za/GradedReadersandBigBookHL.aspx',
        languages: ['All 11 official languages']
      },
    ],
  },
  {
    category: 'Digital Resources',
    description: 'Comprehensive digital resources for Grades 4–12',
    links: [
      { 
        title: 'Digital Textbooks & Concept Maps (Gr4-12)', 
        url: 'https://www.education.gov.za/DigitalContent.aspx',
        languages: ['Multiple languages available']
      },
    ],
  },
  {
    category: 'Grade 12 Study Guides',
    description: 'CAPS-aligned study guides for Grade 12 learners',
    links: [
      { 
        grade: 'Grade 12', 
        title: 'Mind the Gap Study Guides', 
        url: 'https://www.education.gov.za/MindtheGapStudyGuides.aspx',
        languages: ['English', 'Afrikaans']
      },
    ],
  },
];
