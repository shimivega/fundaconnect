export const youtubeFeaturedVideos = [
  {
    title: "Afrikaans Basics",
    videoId: "eH7gaFCKdlA",
    description: "Perfect for Grade 1-3 Afrikaans introduction",
    grade: "Grade 1-3",
    subject: "Afrikaans",
    url: "https://www.youtube.com/embed/eH7gaFCKdlA"
  },
  {
    title: "Grade 1 Addition",
    videoId: "VScM8Z8Jls0",
    description: "Basic addition concepts for young learners",
    grade: "Grade 1",
    subject: "Mathematics",
    url: "https://www.youtube.com/embed/VScM8Z8Jls0"
  },
  {
    title: "Mental Math Tricks",
    videoId: "nTn9gVqRfKY",
    description: "Advanced techniques for faster calculations",
    grade: "Grade 4-7",
    subject: "Mathematics",
    url: "https://www.youtube.com/embed/nTn9gVqRfKY"
  },
  {
    title: "Photosynthesis Quiz",
    videoId: "A7XrwQ6jTZs",
    description: "Interactive quiz about plant photosynthesis",
    grade: "Grade 6-8",
    subject: "Science",
    url: "https://www.youtube.com/embed/A7XrwQ6jTZs"
  },
  {
    title: "Telling Time",
    videoId: "QU-XUmujbuM",
    description: "Learn to read analog and digital clocks",
    grade: "Grade 2-4",
    subject: "Mathematics",
    url: "https://www.youtube.com/embed/QU-XUmujbuM"
  },
  {
    title: "Grade 12 Memo Guide",
    videoId: "NoJmaaoDhMg",
    description: "Comprehensive guide for Grade 12 exam preparation",
    grade: "Grade 12",
    subject: "General",
    url: "https://www.youtube.com/embed/NoJmaaoDhMg?list=PLpjHwiufZtSJn5GlPnqb_KQuvCTbJ9T_6"
  }
];

export const additionalEducationalVideos = [
  "https://www.youtube.com/watch?v=Nj0vzQWvQgw",
  "https://www.youtube.com/watch?v=FaoHl12hAiY", 
  "https://www.youtube.com/watch?v=eEVDsKITxbo",
  "https://www.youtube.com/watch?v=8irU5BM6EoU",
  "https://www.youtube.com/watch?v=q5WgK499V0o",
  "https://www.youtube.com/watch?v=9LH7EjRG9m0",
  "https://www.youtube.com/watch?v=_TaE_fEG_wQ&list=PL8j3onXW6Xzsbs0szBeXzqKhT5fyRo0Q0",
  "https://www.youtube.com/watch?v=QQKz6hNCHFg&list=PL8j3onXW6Xzsbs0szBeXzqKhT5fyRo0Q0&index=2",
  "https://www.youtube.com/watch?v=oS3k-73TOC8&list=PL8j3onXW6Xzsbs0szBeXzqKhT5fyRo0Q0&index=7",
  "https://www.youtube.com/watch?v=E2EIqCw6EFk",
  "https://www.youtube.com/watch?v=D8TmQ5hIPD4"
];
