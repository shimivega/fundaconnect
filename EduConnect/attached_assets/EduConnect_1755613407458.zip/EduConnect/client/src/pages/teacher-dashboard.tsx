import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Classroom, Content, Notification } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navigation from "@/components/navigation";
import ClassroomCard from "@/components/classroom-card";
import ContentUpload from "@/components/content-upload";
import QuizCreator from "@/components/quiz-creator";
import VideoPlayer from "@/components/video-player";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Plus, 
  Users, 
  BookOpen, 
  Trophy, 
  Bell,
  Video,
  Upload,
  MessageSquare,
  BarChart3,
  Calendar
} from "lucide-react";
import { youtubeFeaturedVideos } from "@/data/youtube-videos";

export default function TeacherDashboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch teacher's classrooms
  const { data: classrooms = [], isLoading: classroomsLoading } = useQuery<Classroom[]>({
    queryKey: ["/api/classrooms"],
    enabled: !!user,
    retry: false,
  });

  // Fetch teacher's content
  const { data: content = [], isLoading: contentLoading } = useQuery<Content[]>({
    queryKey: ["/api/content"],
    enabled: !!user,
    retry: false,
  });

  // Fetch notifications
  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    enabled: !!user,
    retry: false,
  });

  // Create classroom mutation
  const createClassroomMutation = useMutation({
    mutationFn: async (classroomData: any) => {
      const response = await apiRequest("POST", "/api/classrooms", classroomData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classrooms"] });
      toast({
        title: "Success",
        description: "Classroom created successfully!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create classroom",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 mx-auto bg-gradient-to-r from-sa-green to-sa-blue rounded-full mb-3 animate-pulse"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user || user.role !== 'teacher') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
            <p className="text-gray-600 mb-4">This page is only accessible to teachers.</p>
            <Button onClick={() => window.location.href = "/"}>
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleCreateClassroom = () => {
    // Mock classroom creation - in real app, this would open a modal
    const mockClassroom = {
      name: `Grade ${Math.floor(Math.random() * 12) + 1} ${['Mathematics', 'Science', 'English'][Math.floor(Math.random() * 3)]}`,
      grade: `Grade ${Math.floor(Math.random() * 12) + 1}`,
      subject: ['Mathematics', 'Science', 'English'][Math.floor(Math.random() * 3)],
      description: "A new classroom for interactive learning"
    };
    createClassroomMutation.mutate(mockClassroom);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-sa-green to-sa-green-light rounded-xl p-6 mb-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold mb-2">
                Welcome back, {user.firstName || 'Teacher'}!
              </h2>
              <p className="text-white/90">
                Ready to inspire your learners today? You have {classrooms.length} classes and {
                  classrooms.length * 25
                } active students.
              </p>
            </div>
            <div className="hidden lg:block">
              <img 
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                alt="Teacher in classroom" 
                className="rounded-lg shadow-lg w-80 h-48 object-cover" 
              />
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-md transition-shadow" data-testid="stat-active-classes">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-blue/10">
                  <Users className="text-sa-blue text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Classes</p>
                  <p className="text-2xl font-bold text-gray-900">{classrooms.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-total-learners">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-green/10">
                  <BookOpen className="text-sa-green text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Learners</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {classrooms.length * 25}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-content-items">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-gold/10">
                  <Upload className="text-sa-gold text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Content Items</p>
                  <p className="text-2xl font-bold text-gray-900">{content.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-notifications">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-red/10">
                  <Bell className="text-sa-red text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Notifications</p>
                  <p className="text-2xl font-bold text-gray-900">{notifications.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Classrooms & Content Management */}
          <div className="lg:col-span-2 space-y-8">
            {/* Classroom Management */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl font-bold text-gray-900">My Classrooms</CardTitle>
                  <Button 
                    onClick={handleCreateClassroom}
                    disabled={createClassroomMutation.isPending}
                    className="bg-sa-green hover:bg-sa-green-light text-white"
                    data-testid="button-create-classroom"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    {createClassroomMutation.isPending ? 'Creating...' : 'Create Classroom'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {classroomsLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="border border-gray-200 rounded-lg p-4 animate-pulse">
                        <div className="h-4 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    ))}
                  </div>
                ) : classrooms.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {classrooms.map((classroom: any) => (
                      <ClassroomCard key={classroom.id} classroom={classroom} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No classrooms yet</h3>
                    <p className="text-gray-600 mb-4">Create your first classroom to get started</p>
                    <Button 
                      onClick={handleCreateClassroom}
                      className="bg-sa-green hover:bg-sa-green-light text-white"
                      data-testid="button-create-first-classroom"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Create Your First Classroom
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Content Management Tabs */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-gray-900">Content Management</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="upload" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="upload" data-testid="tab-upload">Upload Content</TabsTrigger>
                    <TabsTrigger value="quiz" data-testid="tab-quiz">Create Quiz</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="upload" className="mt-6">
                    <ContentUpload />
                  </TabsContent>
                  
                  <TabsContent value="quiz" className="mt-6">
                    <QuizCreator />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Quick Actions & Educational Videos */}
          <div className="space-y-8">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-gray-900">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="ghost" 
                  className="w-full justify-start hover:bg-sa-green/5"
                  data-testid="button-create-test"
                >
                  <div className="w-10 h-10 bg-sa-green/10 rounded-lg flex items-center justify-center mr-3">
                    <Calendar className="h-5 w-5 text-sa-green" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">Create Timed Test</p>
                    <p className="text-sm text-gray-600">Set up synchronized assessments</p>
                  </div>
                </Button>
                
                <Button 
                  variant="ghost" 
                  className="w-full justify-start hover:bg-sa-blue/5"
                  data-testid="button-send-notification"
                >
                  <div className="w-10 h-10 bg-sa-blue/10 rounded-lg flex items-center justify-center mr-3">
                    <Bell className="h-5 w-5 text-sa-blue" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">Send Notification</p>
                    <p className="text-sm text-gray-600">Alert learners about assignments</p>
                  </div>
                </Button>

                <Button 
                  variant="ghost" 
                  className="w-full justify-start hover:bg-sa-gold/5"
                  data-testid="button-view-analytics"
                >
                  <div className="w-10 h-10 bg-sa-gold/10 rounded-lg flex items-center justify-center mr-3">
                    <BarChart3 className="h-5 w-5 text-sa-gold" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">View Analytics</p>
                    <p className="text-sm text-gray-600">Track student progress</p>
                  </div>
                </Button>

                <Button 
                  variant="ghost" 
                  className="w-full justify-start hover:bg-sa-red/5"
                  data-testid="button-message-students"
                >
                  <div className="w-10 h-10 bg-sa-red/10 rounded-lg flex items-center justify-center mr-3">
                    <MessageSquare className="h-5 w-5 text-sa-red" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">Message Students</p>
                    <p className="text-sm text-gray-600">Individual or group messaging</p>
                  </div>
                </Button>
              </CardContent>
            </Card>

            {/* Featured Educational Videos */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-gray-900">Educational Videos</CardTitle>
                <p className="text-sm text-gray-600">Curated content for your lessons</p>
              </CardHeader>
              <CardContent className="space-y-6">
                {youtubeFeaturedVideos.slice(0, 3).map((video, index) => (
                  <div key={index}>
                    <h4 className="font-semibold text-gray-900 mb-2">{video.title}</h4>
                    <VideoPlayer 
                      videoId={video.videoId}
                      title={video.title}
                    />
                    <p className="text-sm text-gray-600 mt-2">{video.description}</p>
                  </div>
                ))}
                
                <Button 
                  variant="outline" 
                  className="w-full border-sa-green text-sa-green hover:bg-sa-green hover:text-white"
                  data-testid="button-view-more-videos"
                >
                  <Video className="h-4 w-4 mr-2" />
                  View More Videos
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Recent Content Section */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-900">Recent Content</CardTitle>
          </CardHeader>
          <CardContent>
            {contentLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center p-3 bg-gray-50 rounded-lg animate-pulse">
                    <div className="w-8 h-8 bg-gray-200 rounded mr-3"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded mb-1"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : content.length > 0 ? (
              <div className="space-y-2">
                {content.slice(0, 5).map((item: any) => (
                  <div key={item.id} className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className={`w-8 h-8 rounded flex items-center justify-center mr-3 ${
                      item.type === 'pdf' ? 'bg-sa-red/10' :
                      item.type === 'video' ? 'bg-sa-blue/10' :
                      'bg-sa-green/10'
                    }`}>
                      {item.type === 'pdf' && <BookOpen className="h-4 w-4 text-sa-red" />}
                      {item.type === 'video' && <Video className="h-4 w-4 text-sa-blue" />}
                      {item.type === 'youtube' && <Video className="h-4 w-4 text-sa-green" />}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{item.title}</p>
                      <p className="text-xs text-gray-600">
                        {item.grade} • {item.subject} • {new Date(item.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Button size="sm" variant="ghost" data-testid={`button-share-${item.id}`}>
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No content uploaded yet</h3>
                <p className="text-gray-600">Start uploading educational materials for your students</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Floating Action Buttons for Mobile */}
      <div className="fixed bottom-6 right-6 flex flex-col space-y-3 lg:hidden">
        <Button 
          size="sm"
          className="w-12 h-12 bg-sa-green hover:bg-sa-green-light text-white rounded-full shadow-lg"
          onClick={handleCreateClassroom}
          data-testid="button-fab-add"
        >
          <Plus className="h-5 w-5" />
        </Button>
        <Button 
          size="sm"
          className="w-12 h-12 bg-sa-blue hover:bg-sa-blue/80 text-white rounded-full shadow-lg"
          data-testid="button-fab-video"
        >
          <Video className="h-5 w-5" />
        </Button>
        <Button 
          size="sm"
          className="w-12 h-12 bg-sa-gold hover:bg-sa-gold-light text-white rounded-full shadow-lg"
          data-testid="button-fab-notification"
        >
          <Bell className="h-5 w-5" />
        </Button>
      </div>
    </div>
  );
}
