import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import type { Classroom, Content, Notification } from "@shared/schema";
import Navigation from "@/components/navigation";
import VideoPlayer from "@/components/video-player";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  Trophy, 
  Calendar,
  Clock,
  Star,
  PlayCircle,
  FileText,
  Users,
  Target
} from "lucide-react";
import { youtubeFeaturedVideos } from "@/data/youtube-videos";
import { saEducationalResources } from "@/data/educational-resources";

export default function LearnerDashboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch learner's classrooms
  const { data: classrooms = [] } = useQuery<Classroom[]>({
    queryKey: ["/api/classrooms"],
    enabled: !!user,
    retry: false,
  });

  // Fetch available content
  const { data: content = [] } = useQuery<Content[]>({
    queryKey: ["/api/content"],
    enabled: !!user,
    retry: false,
  });

  // Fetch notifications
  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    enabled: !!user,
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 mx-auto bg-gradient-to-r from-sa-green to-sa-blue rounded-full mb-3 animate-pulse"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  // Mock learner stats
  const learnerStats = {
    completedLessons: 24,
    totalXP: 1250,
    currentStreak: 7,
    rank: 'Bronze Scholar'
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-sa-blue to-sa-green rounded-xl p-6 mb-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold mb-2">
                Welcome back, {user?.firstName || 'Learner'}!
              </h2>
              <p className="text-white/90">
                Continue your learning journey. You're enrolled in {classrooms.length} classes and have earned {learnerStats.totalXP} XP points!
              </p>
            </div>
            <div className="hidden lg:block">
              <img 
                src="https://images.unsplash.com/photo-1497486751825-1233686d5d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                alt="Students studying" 
                className="rounded-lg shadow-lg w-80 h-48 object-cover" 
              />
            </div>
          </div>
        </div>

        {/* Learning Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-md transition-shadow" data-testid="stat-completed-lessons">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-green/10">
                  <BookOpen className="text-sa-green text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Completed Lessons</p>
                  <p className="text-2xl font-bold text-gray-900">{learnerStats.completedLessons}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-total-xp">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-gold/10">
                  <Trophy className="text-sa-gold text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total XP</p>
                  <p className="text-2xl font-bold text-gray-900">{learnerStats.totalXP}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-current-streak">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-blue/10">
                  <Target className="text-sa-blue text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Current Streak</p>
                  <p className="text-2xl font-bold text-gray-900">{learnerStats.currentStreak} days</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-learner-rank">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-red/10">
                  <Star className="text-sa-red text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Current Rank</p>
                  <p className="text-lg font-bold text-gray-900">{learnerStats.rank}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Classrooms & Activities */}
          <div className="lg:col-span-2 space-y-8">
            {/* My Classrooms */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-gray-900">My Classrooms</CardTitle>
              </CardHeader>
              <CardContent>
                {classrooms.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {classrooms.map((classroom: any) => (
                      <div key={classroom.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-sa-blue/10 rounded-lg flex items-center justify-center">
                              <BookOpen className="h-5 w-5 text-sa-blue" />
                            </div>
                            <div className="ml-3">
                              <h4 className="font-semibold text-gray-900">{classroom.name}</h4>
                              <p className="text-sm text-gray-600">{classroom.grade} • {classroom.subject}</p>
                            </div>
                          </div>
                          <Button size="sm" data-testid={`button-join-${classroom.id}`}>
                            <Users className="w-4 h-4 mr-1" />
                            Join
                          </Button>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">Next: Assignment Due</span>
                          <Badge variant="secondary">Active</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No classrooms joined yet</h3>
                    <p className="text-gray-600 mb-4">Join classrooms to access lessons and assignments</p>
                    <Button className="bg-sa-green hover:bg-sa-green-light text-white" data-testid="button-browse-classrooms">
                      <Users className="h-4 w-4 mr-2" />
                      Browse Classrooms
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Learning Resources */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-gray-900">Learning Resources</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="videos" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="videos" data-testid="tab-videos">Videos</TabsTrigger>
                    <TabsTrigger value="materials" data-testid="tab-materials">Materials</TabsTrigger>
                    <TabsTrigger value="quizzes" data-testid="tab-quizzes">Quizzes</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="videos" className="mt-6">
                    <div className="space-y-4">
                      {youtubeFeaturedVideos.slice(0, 3).map((video, index) => (
                        <div key={index} className="border border-gray-200 rounded-lg p-4">
                          <h4 className="font-semibold text-gray-900 mb-2">{video.title}</h4>
                          <div className="aspect-video mb-2">
                            <VideoPlayer 
                              videoId={video.videoId}
                              title={video.title}
                            />
                          </div>
                          <p className="text-sm text-gray-600">{video.description}</p>
                          <div className="flex items-center justify-between mt-3">
                            <Badge variant="outline">{video.grade}</Badge>
                            <Button size="sm" variant="ghost" data-testid={`button-save-${index}`}>
                              <Star className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="materials" className="mt-6">
                    <div className="space-y-3">
                      {content.slice(0, 5).map((item: any) => (
                        <div key={item.id} className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                          <div className={`w-8 h-8 rounded flex items-center justify-center mr-3 ${
                            item.type === 'pdf' ? 'bg-sa-red/10' :
                            item.type === 'video' ? 'bg-sa-blue/10' :
                            'bg-sa-green/10'
                          }`}>
                            <FileText className="h-4 w-4 text-sa-red" />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900">{item.title}</p>
                            <p className="text-xs text-gray-600">{item.grade} • {item.subject}</p>
                          </div>
                          <Button size="sm" variant="ghost" data-testid={`button-download-${item.id}`}>
                            <PlayCircle className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="quizzes" className="mt-6">
                    <div className="text-center py-8">
                      <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No quizzes available</h3>
                      <p className="text-gray-600">Check back later for new assessments</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Progress & Educational Resources */}
          <div className="space-y-8">
            {/* Learning Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-gray-900">Learning Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700">Weekly Goal</span>
                    <span className="text-sm text-gray-600">5/7 days</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-sa-green h-2 rounded-full" style={{ width: '71%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-700">XP to Next Level</span>
                    <span className="text-sm text-gray-600">250/500 XP</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-sa-gold h-2 rounded-full" style={{ width: '50%' }}></div>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <h4 className="font-semibold text-gray-900 mb-3">Recent Achievements</h4>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-sa-gold/10 rounded-full flex items-center justify-center mr-3">
                        <Trophy className="h-4 w-4 text-sa-gold" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">Quiz Master</p>
                        <p className="text-xs text-gray-600">Completed 5 quizzes</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-sa-blue/10 rounded-full flex items-center justify-center mr-3">
                        <Star className="h-4 w-4 text-sa-blue" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">Consistent Learner</p>
                        <p className="text-xs text-gray-600">7-day streak</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Educational Resources by Subject */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-gray-900">Study Resources</CardTitle>
                <p className="text-sm text-gray-600">Curriculum-aligned materials</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {saEducationalResources.slice(0, 4).map((subject, index) => (
                    <Button 
                      key={index}
                      variant="ghost" 
                      className="w-full justify-start hover:bg-sa-green/5"
                      data-testid={`button-subject-${subject.subject.toLowerCase()}`}
                    >
                      <div className="w-10 h-10 bg-sa-green/10 rounded-lg flex items-center justify-center mr-3">
                        <BookOpen className="h-5 w-5 text-sa-green" />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-gray-900">{subject.subject}</p>
                        <p className="text-sm text-gray-600">Grades R-12 resources</p>
                      </div>
                    </Button>
                  ))}
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full mt-4 border-sa-green text-sa-green hover:bg-sa-green hover:text-white"
                  data-testid="button-browse-all-resources"
                >
                  <BookOpen className="h-4 w-4 mr-2" />
                  Browse All Resources
                </Button>
              </CardContent>
            </Card>

            {/* Upcoming Events */}
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-bold text-gray-900">Upcoming Events</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center p-3 bg-sa-blue/5 rounded-lg">
                    <div className="w-10 h-10 bg-sa-blue/10 rounded-lg flex items-center justify-center mr-3">
                      <Calendar className="h-5 w-5 text-sa-blue" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">Math Quiz</p>
                      <p className="text-xs text-gray-600">Tomorrow, 10:00 AM</p>
                    </div>
                    <Badge variant="secondary">
                      <Clock className="h-3 w-3 mr-1" />
                      1 day
                    </Badge>
                  </div>
                  
                  <div className="flex items-center p-3 bg-sa-green/5 rounded-lg">
                    <div className="w-10 h-10 bg-sa-green/10 rounded-lg flex items-center justify-center mr-3">
                      <Users className="h-5 w-5 text-sa-green" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">Science Lab</p>
                      <p className="text-xs text-gray-600">Friday, 2:00 PM</p>
                    </div>
                    <Badge variant="secondary">
                      <Clock className="h-3 w-3 mr-1" />
                      3 days
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
