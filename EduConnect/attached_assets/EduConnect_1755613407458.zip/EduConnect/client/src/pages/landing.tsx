import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  GraduationCap, 
  Users, 
  BookOpen, 
  Trophy,
  Globe,
  Star,
  Play,
  Upload
} from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sa-green/5 to-sa-blue/5">
      {/* Header */}
      <nav className="bg-white shadow-sm border-b-2 border-sa-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="w-8 h-8 bg-gradient-to-r from-sa-green to-sa-blue rounded-full mr-3"></div>
              <h1 className="text-2xl font-bold text-sa-green">Funda-App</h1>
            </div>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-sa-green hover:bg-sa-green-light text-white"
              data-testid="button-login"
            >
              Sign In
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Education for Every
            <span className="text-sa-green"> South African </span>
            Learner
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            A comprehensive educational platform supporting all 11 official languages, 
            connecting teachers and learners across South Africa with quality resources and interactive learning.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg"
              onClick={() => window.location.href = '/api/login'}
              className="bg-sa-green hover:bg-sa-green-light text-white px-8 py-4 text-lg"
              data-testid="button-get-started"
            >
              <GraduationCap className="mr-2 h-5 w-5" />
              Get Started
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-sa-green text-sa-green hover:bg-sa-green hover:text-white px-8 py-4 text-lg"
              data-testid="button-learn-more"
            >
              <Play className="mr-2 h-5 w-5" />
              Watch Demo
            </Button>
          </div>
        </div>

        {/* Hero Image */}
        <div className="relative max-w-4xl mx-auto">
          <div className="rounded-xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1580582932707-520aed937b7b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600" 
              alt="South African students learning together"
              className="w-full h-96 object-cover"
            />
          </div>
          <div className="absolute -bottom-6 -right-6 bg-sa-gold rounded-lg p-4 shadow-lg">
            <div className="flex items-center text-white">
              <Users className="h-6 w-6 mr-2" />
              <div>
                <p className="font-bold">10,000+</p>
                <p className="text-sm">Active Learners</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Everything You Need for Quality Education
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From virtual classrooms to multilingual content, we provide the tools 
              for effective teaching and learning.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <Card className="border-2 border-transparent hover:border-sa-green transition-colors">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-sa-green/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-sa-green" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Virtual Classrooms</h3>
                <p className="text-gray-600">
                  Create and manage online classrooms with video calls, messaging, and collaborative tools.
                </p>
              </CardContent>
            </Card>

            {/* Feature 2 */}
            <Card className="border-2 border-transparent hover:border-sa-blue transition-colors">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-sa-blue/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-6 w-6 text-sa-blue" />
                </div>
                <h3 className="text-xl font-semibold mb-2">11 Languages</h3>
                <p className="text-gray-600">
                  Content and quizzes available in all South African official languages.
                </p>
              </CardContent>
            </Card>

            {/* Feature 3 */}
            <Card className="border-2 border-transparent hover:border-sa-gold transition-colors">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-sa-gold/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Upload className="h-6 w-6 text-sa-gold" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Content Management</h3>
                <p className="text-gray-600">
                  Upload and organize PDFs, videos, and educational materials by grade and subject.
                </p>
              </CardContent>
            </Card>

            {/* Feature 4 */}
            <Card className="border-2 border-transparent hover:border-sa-red transition-colors">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-sa-red/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="h-6 w-6 text-sa-red" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Interactive Quizzes</h3>
                <p className="text-gray-600">
                  Create and schedule timed tests with automatic grading and progress tracking.
                </p>
              </CardContent>
            </Card>

            {/* Feature 5 */}
            <Card className="border-2 border-transparent hover:border-sa-green transition-colors">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-sa-green/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Trophy className="h-6 w-6 text-sa-green" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Educational Games</h3>
                <p className="text-gray-600">
                  Engaging games and activities to make learning fun and interactive.
                </p>
              </CardContent>
            </Card>

            {/* Feature 6 */}
            <Card className="border-2 border-transparent hover:border-sa-blue transition-colors">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-sa-blue/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Star className="h-6 w-6 text-sa-blue" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Progress Tracking</h3>
                <p className="text-gray-600">
                  Monitor student performance with detailed analytics and reporting.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Educational Resources Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Curriculum-Aligned Resources
            </h2>
            <p className="text-lg text-gray-600">
              Access educational materials for all grades and subjects
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Resource Images */}
            <div className="bg-white rounded-lg p-4 shadow-sm">
              <img 
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                alt="Teacher in modern classroom"
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
              <h4 className="font-semibold text-gray-900 mb-1">Modern Teaching</h4>
              <p className="text-sm text-gray-600">Technology-enhanced learning</p>
            </div>

            <div className="bg-white rounded-lg p-4 shadow-sm">
              <img 
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                alt="Digital learning tools"
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
              <h4 className="font-semibold text-gray-900 mb-1">Digital Tools</h4>
              <p className="text-sm text-gray-600">Interactive platforms</p>
            </div>

            <div className="bg-white rounded-lg p-4 shadow-sm">
              <img 
                src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                alt="Educational textbooks"
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
              <h4 className="font-semibold text-gray-900 mb-1">Textbooks</h4>
              <p className="text-sm text-gray-600">Grade-specific curriculum</p>
            </div>

            <div className="bg-white rounded-lg p-4 shadow-sm">
              <img 
                src="https://images.unsplash.com/photo-1497486751825-1233686d5d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250" 
                alt="Students studying"
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
              <h4 className="font-semibold text-gray-900 mb-1">Study Groups</h4>
              <p className="text-sm text-gray-600">Collaborative learning</p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-sa-green to-sa-blue py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Transform Education?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of teachers and learners already using Funda-App 
            to create better educational experiences.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-white text-sa-green hover:bg-gray-100 px-8 py-4 text-lg font-semibold"
            data-testid="button-join-now"
          >
            <GraduationCap className="mr-2 h-5 w-5" />
            Join Funda-App Today
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="w-6 h-6 bg-gradient-to-r from-sa-green to-sa-blue rounded-full mr-2"></div>
              <span className="text-lg font-semibold">Funda-App</span>
            </div>
            <p className="text-gray-400 text-sm">
              © 2025 Funda-App. Empowering South African education.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
