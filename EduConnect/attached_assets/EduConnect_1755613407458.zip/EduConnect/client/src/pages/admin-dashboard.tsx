import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import type { Classroom, Content } from "@shared/schema";
import Navigation from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  BookOpen, 
  FileText, 
  Settings,
  BarChart3,
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Globe,
  Upload
} from "lucide-react";

export default function AdminDashboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch all classrooms for admin view
  const { data: classrooms = [] } = useQuery<Classroom[]>({
    queryKey: ["/api/classrooms"],
    enabled: !!user,
    retry: false,
  });

  // Fetch all content for moderation
  const { data: content = [] } = useQuery<Content[]>({
    queryKey: ["/api/content"],
    enabled: !!user,
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 mx-auto bg-gradient-to-r from-sa-green to-sa-blue rounded-full mb-3 animate-pulse"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
            <p className="text-gray-600 mb-4">This page is only accessible to administrators.</p>
            <Button onClick={() => window.location.href = "/"}>
              Go to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Mock admin statistics
  const adminStats = {
    totalUsers: 1247,
    totalTeachers: 89,
    totalLearners: 1158,
    totalClassrooms: classrooms.length,
    pendingContent: content.filter((item: any) => !item.isApproved).length,
    totalContent: content.length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-sa-red to-sa-gold rounded-xl p-6 mb-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold mb-2">
                Admin Dashboard
              </h2>
              <p className="text-white/90">
                Monitor and manage the Funda-App platform. {adminStats.totalUsers} users, {adminStats.totalClassrooms} classrooms active.
              </p>
            </div>
            <div className="hidden lg:block">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <Shield className="h-8 w-8 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* System Stats */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-6 mb-8">
          <Card className="hover:shadow-md transition-shadow" data-testid="stat-total-users">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-blue/10">
                  <Users className="text-sa-blue text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold text-gray-900">{adminStats.totalUsers}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-teachers">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-green/10">
                  <Users className="text-sa-green text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Teachers</p>
                  <p className="text-2xl font-bold text-gray-900">{adminStats.totalTeachers}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-learners">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-gold/10">
                  <BookOpen className="text-sa-gold text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Learners</p>
                  <p className="text-2xl font-bold text-gray-900">{adminStats.totalLearners}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-classrooms">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-red/10">
                  <Globe className="text-sa-red text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Classrooms</p>
                  <p className="text-2xl font-bold text-gray-900">{adminStats.totalClassrooms}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-content">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-blue/10">
                  <FileText className="text-sa-blue text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Content Items</p>
                  <p className="text-2xl font-bold text-gray-900">{adminStats.totalContent}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow" data-testid="stat-pending">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-sa-gold/10">
                  <AlertTriangle className="text-sa-gold text-xl h-6 w-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Pending</p>
                  <p className="text-2xl font-bold text-gray-900">{adminStats.pendingContent}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Admin Interface */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-900">Platform Management</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="content" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="content" data-testid="tab-content">Content Moderation</TabsTrigger>
                <TabsTrigger value="users" data-testid="tab-users">User Management</TabsTrigger>
                <TabsTrigger value="analytics" data-testid="tab-analytics">Analytics</TabsTrigger>
                <TabsTrigger value="settings" data-testid="tab-settings">Settings</TabsTrigger>
              </TabsList>
              
              <TabsContent value="content" className="mt-6">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">Content Approval Queue</h3>
                    <Badge variant={adminStats.pendingContent > 0 ? "destructive" : "default"}>
                      {adminStats.pendingContent} pending
                    </Badge>
                  </div>
                  
                  <div className="space-y-3">
                    {content.filter((item: any) => !item.isApproved).length > 0 ? (
                      content.filter((item: any) => !item.isApproved).map((item: any) => (
                        <div key={item.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                          <div className="flex items-center">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-4 ${
                              item.type === 'pdf' ? 'bg-sa-red/10' :
                              item.type === 'video' ? 'bg-sa-blue/10' :
                              'bg-sa-green/10'
                            }`}>
                              {item.type === 'pdf' && <FileText className="h-5 w-5 text-sa-red" />}
                              {item.type === 'video' && <Upload className="h-5 w-5 text-sa-blue" />}
                              {item.type === 'youtube' && <Upload className="h-5 w-5 text-sa-green" />}
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900">{item.title}</h4>
                              <p className="text-sm text-gray-600">
                                {item.grade} • {item.subject} • Uploaded by {item.uploadedBy}
                              </p>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="border-sa-green text-sa-green hover:bg-sa-green hover:text-white"
                              data-testid={`button-approve-${item.id}`}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="border-sa-red text-sa-red hover:bg-sa-red hover:text-white"
                              data-testid={`button-reject-${item.id}`}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8">
                        <CheckCircle className="h-12 w-12 text-sa-green mx-auto mb-4" />
                        <h3 className="text-lg font-medium text-gray-900 mb-2">All content approved</h3>
                        <p className="text-gray-600">No pending content items require review</p>
                      </div>
                    )}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="users" className="mt-6">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">User Management</h3>
                    <div className="flex space-x-2">
                      <Badge variant="outline">{adminStats.totalTeachers} Teachers</Badge>
                      <Badge variant="outline">{adminStats.totalLearners} Learners</Badge>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-6 text-center">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">User Management Tools</h3>
                    <p className="text-gray-600 mb-4">Advanced user management features will be available here</p>
                    <div className="flex justify-center space-x-3">
                      <Button variant="outline" data-testid="button-export-users">
                        Export Users
                      </Button>
                      <Button variant="outline" data-testid="button-send-broadcast">
                        Send Broadcast
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="analytics" className="mt-6">
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-gray-900">Platform Analytics</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">User Growth</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-32 bg-gradient-to-r from-sa-green/10 to-sa-blue/10 rounded-lg flex items-center justify-center">
                          <BarChart3 className="h-8 w-8 text-sa-green" />
                          <span className="ml-2 text-gray-600">Chart placeholder</span>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Content Usage</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="h-32 bg-gradient-to-r from-sa-gold/10 to-sa-red/10 rounded-lg flex items-center justify-center">
                          <BarChart3 className="h-8 w-8 text-sa-gold" />
                          <span className="ml-2 text-gray-600">Chart placeholder</span>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="settings" className="mt-6">
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-gray-900">Platform Settings</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">System Configuration</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">Auto-approve teacher content</span>
                          <Button size="sm" variant="outline" data-testid="button-toggle-auto-approve">
                            Enabled
                          </Button>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">File upload limit</span>
                          <span className="text-sm text-gray-600">50MB</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-700">Max classroom size</span>
                          <span className="text-sm text-gray-600">100 students</span>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Site Customization</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Platform Logo
                          </label>
                          <Button variant="outline" data-testid="button-upload-logo">
                            <Upload className="h-4 w-4 mr-2" />
                            Upload Logo
                          </Button>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Welcome Message
                          </label>
                          <textarea 
                            className="w-full p-2 border border-gray-300 rounded-md"
                            rows={3}
                            placeholder="Welcome to Funda-App..."
                            data-testid="textarea-welcome-message"
                          />
                        </div>
                        <Button className="bg-sa-green hover:bg-sa-green-light text-white" data-testid="button-save-settings">
                          <Settings className="h-4 w-4 mr-2" />
                          Save Settings
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
