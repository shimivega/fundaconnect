import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Upload, 
  FileText, 
  Video, 
  Link,
  AlertCircle,
  CheckCircle,
  Loader2
} from "lucide-react";

const grades = [
  "Grade R", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5",
  "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"
];

const subjects = [
  "Mathematics", "Science", "English", "Afrikaans", "IsiZulu", "IsiXhosa",
  "History", "Geography", "Life Skills", "Technology", "Arts", "Physical Education"
];

const languages = [
  "English", "Afrikaans", "IsiZulu", "IsiXhosa", "Sepedi", "Sesotho",
  "Setswana", "Tshivenda", "Xitsonga", "SiSwati", "IsiNdebele"
];

export default function ContentUpload() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [uploadType, setUploadType] = useState<"file" | "youtube">("file");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    grade: "",
    subject: "",
    language: "English",
    url: "",
    classroomId: ""
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: FormData | any) => {
      const url = "/api/content";
      if (data instanceof FormData) {
        // File upload
        const response = await fetch(url, {
          method: "POST",
          body: data,
          credentials: "include"
        });
        if (!response.ok) {
          const text = await response.text();
          throw new Error(`${response.status}: ${text}`);
        }
        return response.json();
      } else {
        // YouTube URL upload
        const response = await apiRequest("POST", url, data);
        return response.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/content"] });
      toast({
        title: "Success",
        description: "Content uploaded successfully!",
      });
      // Reset form
      setFormData({
        title: "",
        description: "",
        grade: "",
        subject: "",
        language: "English",
        url: "",
        classroomId: ""
      });
      setSelectedFile(null);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to upload content",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      if (!formData.title) {
        setFormData(prev => ({ ...prev, title: file.name }));
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (uploadType === "file") {
      if (!selectedFile) {
        toast({
          title: "Error",
          description: "Please select a file to upload",
          variant: "destructive",
        });
        return;
      }

      const data = new FormData();
      data.append("file", selectedFile);
      data.append("title", formData.title);
      data.append("description", formData.description);
      data.append("grade", formData.grade);
      data.append("subject", formData.subject);
      data.append("language", formData.language);
      if (formData.classroomId) {
        data.append("classroomId", formData.classroomId);
      }

      uploadMutation.mutate(data);
    } else {
      if (!formData.url) {
        toast({
          title: "Error",
          description: "Please provide a YouTube URL",
          variant: "destructive",
        });
        return;
      }

      uploadMutation.mutate({
        ...formData,
        type: "youtube"
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Type Selection */}
      <div className="flex space-x-4">
        <Button
          type="button"
          variant={uploadType === "file" ? "default" : "outline"}
          onClick={() => setUploadType("file")}
          className={uploadType === "file" ? "bg-sa-green hover:bg-sa-green-light text-white" : ""}
          data-testid="button-upload-file"
        >
          <Upload className="h-4 w-4 mr-2" />
          Upload File
        </Button>
        <Button
          type="button"
          variant={uploadType === "youtube" ? "default" : "outline"}
          onClick={() => setUploadType("youtube")}
          className={uploadType === "youtube" ? "bg-sa-blue hover:bg-sa-blue/80 text-white" : ""}
          data-testid="button-upload-youtube"
        >
          <Video className="h-4 w-4 mr-2" />
          Add YouTube Video
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* File Upload or YouTube URL */}
        {uploadType === "file" ? (
          <Card className="border-2 border-dashed border-gray-300 hover:border-sa-green transition-colors">
            <CardContent className="p-6">
              <div className="text-center">
                <input
                  type="file"
                  accept=".pdf,.mp4,.avi,.mov,.jpg,.jpeg,.png,.gif"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="file-upload"
                  data-testid="input-file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <div className="w-12 h-12 mx-auto bg-sa-green/10 rounded-lg flex items-center justify-center mb-3">
                    {selectedFile ? (
                      <CheckCircle className="h-6 w-6 text-sa-green" />
                    ) : (
                      <Upload className="h-6 w-6 text-sa-green" />
                    )}
                  </div>
                  <h4 className="font-medium text-gray-900 mb-1">
                    {selectedFile ? selectedFile.name : "Choose a file"}
                  </h4>
                  <p className="text-sm text-gray-600">
                    PDF, Video, or Image files (max 50MB)
                  </p>
                </label>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div>
            <Label htmlFor="youtube-url">YouTube Video URL</Label>
            <div className="relative">
              <Link className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                id="youtube-url"
                type="url"
                placeholder="https://www.youtube.com/watch?v=..."
                value={formData.url}
                onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
                className="pl-10"
                data-testid="input-youtube-url"
              />
            </div>
          </div>
        )}

        {/* Content Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              type="text"
              placeholder="Enter content title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              required
              data-testid="input-content-title"
            />
          </div>
          
          <div>
            <Label htmlFor="grade">Grade *</Label>
            <Select 
              value={formData.grade} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, grade: value }))}
            >
              <SelectTrigger data-testid="select-grade">
                <SelectValue placeholder="Select grade" />
              </SelectTrigger>
              <SelectContent>
                {grades.map((grade) => (
                  <SelectItem key={grade} value={grade}>
                    {grade}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="subject">Subject *</Label>
            <Select 
              value={formData.subject} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, subject: value }))}
            >
              <SelectTrigger data-testid="select-subject">
                <SelectValue placeholder="Select subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subject) => (
                  <SelectItem key={subject} value={subject}>
                    {subject}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="language">Language</Label>
            <Select 
              value={formData.language} 
              onValueChange={(value) => setFormData(prev => ({ ...prev, language: value }))}
            >
              <SelectTrigger data-testid="select-language">
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                {languages.map((language) => (
                  <SelectItem key={language} value={language}>
                    {language}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            placeholder="Enter content description..."
            value={formData.description}
            onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
            rows={3}
            data-testid="textarea-description"
          />
        </div>

        <div className="flex items-center space-x-2 p-3 bg-sa-gold/10 rounded-lg">
          <AlertCircle className="h-4 w-4 text-sa-gold" />
          <p className="text-sm text-gray-700">
            Content will be reviewed by administrators before being published.
          </p>
        </div>

        <Button
          type="submit"
          disabled={uploadMutation.isPending || (!selectedFile && uploadType === "file") || (!formData.url && uploadType === "youtube") || !formData.title || !formData.grade || !formData.subject}
          className="w-full bg-sa-green hover:bg-sa-green-light text-white"
          data-testid="button-submit-content"
        >
          {uploadMutation.isPending ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Uploading...
            </>
          ) : (
            <>
              <Upload className="h-4 w-4 mr-2" />
              Upload Content
            </>
          )}
        </Button>
      </form>
    </div>
  );
}
