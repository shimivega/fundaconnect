interface VideoPlayerProps {
  videoId: string;
  title: string;
  className?: string;
}

export default function VideoPlayer({ videoId, title, className = "" }: VideoPlayerProps) {
  return (
    <div className={`relative w-full ${className}`} style={{ paddingBottom: '56.25%', height: 0 }}>
      <iframe
        src={`https://www.youtube.com/embed/${videoId}`}
        title={title}
        frameBorder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        className="absolute top-0 left-0 w-full h-full rounded-lg"
        data-testid={`video-player-${videoId}`}
      />
    </div>
  );
}
