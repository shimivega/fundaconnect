import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Home, 
  Users, 
  Upload, 
  Gamepad2,
  Settings,
  LogOut,
  Menu,
  X,
  BookOpen
} from "lucide-react";

export default function Navigation() {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState("English");

  const navigationItems = [
    { 
      name: "Dashboard", 
      icon: Home, 
      href: "/", 
      active: true,
      roles: ["admin", "teacher", "learner"]
    },
    { 
      name: "Classrooms", 
      icon: Users, 
      href: "/classrooms", 
      active: false,
      roles: ["teacher", "learner"]
    },
    { 
      name: "Content", 
      icon: Upload, 
      href: "/content", 
      active: false,
      roles: ["admin", "teacher", "learner"]
    },
    { 
      name: "Games", 
      icon: Gamepad2, 
      href: "/games", 
      active: false,
      roles: ["learner"]
    },
    { 
      name: "Resources", 
      icon: BookOpen, 
      href: "/resources", 
      active: false,
      roles: ["learner"]
    },
    { 
      name: "Settings", 
      icon: Settings, 
      href: "/settings", 
      active: false,
      roles: ["admin"]
    }
  ];

  const languages = [
    "English", "Afrikaans", "IsiZulu", "IsiXhosa", "Sepedi", "Sesotho",
    "Setswana", "Tshivenda", "Xitsonga", "SiSwati", "IsiNdebele"
  ];

  const filteredNavigationItems = navigationItems.filter(item => 
    item.roles.includes(user?.role || "learner")
  );

  const getUserInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    return user?.email?.[0]?.toUpperCase() || "U";
  };

  const getUserDisplayName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user?.email || "User";
  };

  const getRoleColor = () => {
    switch (user?.role) {
      case "admin":
        return "text-sa-red";
      case "teacher":
        return "text-sa-green";
      case "learner":
        return "text-sa-blue";
      default:
        return "text-gray-600";
    }
  };

  return (
    <nav className="bg-white shadow-sm border-b-2 border-sa-gold">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Brand */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="w-8 h-8 bg-gradient-to-r from-sa-green to-sa-blue rounded-full mr-3"></div>
              <h1 className="text-2xl font-bold text-sa-green">Funda-App</h1>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block ml-8">
              <div className="flex items-center space-x-4">
                {filteredNavigationItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={item.name}
                      variant="ghost"
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        item.active 
                          ? "text-sa-green bg-sa-green/10" 
                          : "text-gray-600 hover:text-sa-green hover:bg-sa-green/5"
                      }`}
                      data-testid={`nav-${item.name.toLowerCase()}`}
                    >
                      <Icon className="h-4 w-4 mr-1" />
                      {item.name}
                    </Button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Side - Language Selector, User Menu */}
          <div className="flex items-center space-x-4">
            {/* Language Selector */}
            <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
              <SelectTrigger className="w-32 text-sm border-gray-300">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {languages.map((language) => (
                  <SelectItem key={language} value={language}>
                    {language}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* User Profile */}
            <div className="flex items-center space-x-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.profileImageUrl || ""} alt="Profile" />
                <AvatarFallback className="bg-sa-green text-white text-sm">
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>
              <div className="hidden sm:block">
                <p className="text-sm font-medium text-gray-700">
                  {getUserDisplayName()}
                </p>
                <p className={`text-xs capitalize ${getRoleColor()}`}>
                  {user?.role || "User"}
                </p>
              </div>
            </div>

            {/* Logout Button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.location.href = "/api/logout"}
              className="text-gray-600 hover:text-sa-red hover:bg-sa-red/10"
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4" />
            </Button>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <div className="space-y-2">
              {filteredNavigationItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.name}
                    variant="ghost"
                    className={`w-full justify-start px-3 py-2 rounded-md text-sm font-medium ${
                      item.active 
                        ? "text-sa-green bg-sa-green/10" 
                        : "text-gray-600 hover:text-sa-green hover:bg-sa-green/5"
                    }`}
                    data-testid={`mobile-nav-${item.name.toLowerCase()}`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {item.name}
                  </Button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
