import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Calculator, 
  FlaskConical, 
  BookOpen, 
  Video, 
  Users,
  Calendar,
  MessageSquare
} from "lucide-react";

interface ClassroomCardProps {
  classroom: {
    id: string;
    name: string;
    grade: string;
    subject: string;
    description?: string;
    isActive?: boolean;
    enrollments?: any[];
  };
}

export default function ClassroomCard({ classroom }: ClassroomCardProps) {
  const getSubjectIcon = (subject: string) => {
    switch (subject.toLowerCase()) {
      case 'mathematics':
      case 'math':
        return <Calculator className="h-5 w-5 text-sa-blue" />;
      case 'science':
        return <FlaskConical className="h-5 w-5 text-sa-gold" />;
      case 'english':
      case 'afrikaans':
        return <BookOpen className="h-5 w-5 text-sa-red" />;
      default:
        return <BookOpen className="h-5 w-5 text-sa-green" />;
    }
  };

  const getSubjectColor = (subject: string) => {
    switch (subject.toLowerCase()) {
      case 'mathematics':
      case 'math':
        return 'bg-sa-blue/10';
      case 'science':
        return 'bg-sa-gold/10';
      case 'english':
      case 'afrikaans':
        return 'bg-sa-red/10';
      default:
        return 'bg-sa-green/10';
    }
  };

  const enrollmentCount = classroom.enrollments?.length || 0;

  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all duration-200 bg-white">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center">
          <div className={`w-10 h-10 ${getSubjectColor(classroom.subject)} rounded-lg flex items-center justify-center`}>
            {getSubjectIcon(classroom.subject)}
          </div>
          <div className="ml-3">
            <h4 className="font-semibold text-gray-900" data-testid={`classroom-name-${classroom.id}`}>
              {classroom.name}
            </h4>
            <p className="text-sm text-gray-600">
              {classroom.grade} • {enrollmentCount} learner{enrollmentCount !== 1 ? 's' : ''}
            </p>
          </div>
        </div>
        <div className="flex space-x-1">
          <Button 
            size="sm" 
            variant="ghost"
            className="text-sa-green hover:text-sa-green-light hover:bg-sa-green/10"
            data-testid={`button-video-call-${classroom.id}`}
          >
            <Video className="h-4 w-4" />
          </Button>
          <Button 
            size="sm" 
            variant="ghost"
            className="text-sa-blue hover:text-sa-blue/80 hover:bg-sa-blue/10"
            data-testid={`button-message-${classroom.id}`}
          >
            <MessageSquare className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {classroom.description && (
        <p className="text-sm text-gray-600 mb-3" data-testid={`classroom-description-${classroom.id}`}>
          {classroom.description}
        </p>
      )}

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Badge 
            variant={classroom.isActive ? "default" : "secondary"}
            className={classroom.isActive ? "bg-sa-green text-white" : ""}
          >
            {classroom.isActive ? 'Active' : 'Inactive'}
          </Badge>
          <span className="text-xs text-gray-500 flex items-center">
            <Calendar className="h-3 w-3 mr-1" />
            Next: Assignment
          </span>
        </div>
        
        <Button 
          size="sm"
          className="bg-sa-green hover:bg-sa-green-light text-white"
          data-testid={`button-manage-${classroom.id}`}
        >
          <Users className="h-4 w-4 mr-1" />
          Manage
        </Button>
      </div>
    </div>
  );
}
