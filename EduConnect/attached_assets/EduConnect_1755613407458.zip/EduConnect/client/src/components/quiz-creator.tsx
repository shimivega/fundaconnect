import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Plus,
  Trash2,
  Clock,
  BookOpen,
  Loader2,
  CheckCircle
} from "lucide-react";
import { practiceQuestions } from "@/data/practice-questions";

const grades = [
  "Grade R", "Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5",
  "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"
];

const subjects = [
  "Mathematics", "Science", "English", "Afrikaans", "IsiZulu", "IsiXhosa",
  "History", "Geography", "Life Skills", "Technology", "Arts", "Physical Education"
];

const languages = [
  "English", "Afrikaans", "IsiZulu", "IsiXhosa", "Sepedi", "Sesotho",
  "Setswana", "Tshivenda", "Xitsonga", "SiSwati", "IsiNdebele"
];

interface Question {
  question: string;
  options: string[];
  answer: string;
}

export default function QuizCreator() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [quizData, setQuizData] = useState({
    title: "",
    description: "",
    grade: "",
    subject: "",
    language: "English",
    duration: 60,
    classroomId: ""
  });
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<Question>({
    question: "",
    options: ["", "", "", ""],
    answer: ""
  });

  const createQuizMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/quizzes", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
      toast({
        title: "Success",
        description: "Quiz created successfully!",
      });
      // Reset form
      setQuizData({
        title: "",
        description: "",
        grade: "",
        subject: "",
        language: "English",
        duration: 60,
        classroomId: ""
      });
      setQuestions([]);
      setCurrentQuestion({
        question: "",
        options: ["", "", "", ""],
        answer: ""
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create quiz",
        variant: "destructive",
      });
    },
  });

  const addQuestion = () => {
    if (!currentQuestion.question || currentQuestion.options.some(opt => !opt) || !currentQuestion.answer) {
      toast({
        title: "Error",
        description: "Please fill in all question fields",
        variant: "destructive",
      });
      return;
    }

    setQuestions(prev => [...prev, currentQuestion]);
    setCurrentQuestion({
      question: "",
      options: ["", "", "", ""],
      answer: ""
    });
  };

  const removeQuestion = (index: number) => {
    setQuestions(prev => prev.filter((_, i) => i !== index));
  };

  const generatePracticeQuestions = () => {
    if (!quizData.grade || !quizData.subject || !quizData.language) {
      toast({
        title: "Error",
        description: "Please select grade, subject, and language first",
        variant: "destructive",
      });
      return;
    }

    const matchingQuestions = practiceQuestions.filter(
      pq => pq.grade === quizData.grade && 
           pq.subject === quizData.subject
    );

    if (matchingQuestions.length > 0) {
      const questionBank = matchingQuestions[0];
      const languageQuestions = questionBank.questions.filter(
        q => q.language === quizData.language
      );

      if (languageQuestions.length > 0) {
        // Add up to 5 random questions
        const selectedQuestions = languageQuestions
          .sort(() => 0.5 - Math.random())
          .slice(0, 5)
          .map(q => ({
            question: q.question,
            options: q.options,
            answer: q.answer
          }));

        setQuestions(prev => [...prev, ...selectedQuestions]);
        toast({
          title: "Success",
          description: `Added ${selectedQuestions.length} practice questions`,
        });
      } else {
        toast({
          title: "No Questions Found",
          description: `No questions available in ${quizData.language} for ${quizData.subject}`,
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "No Questions Found",
        description: `No questions available for ${quizData.grade} ${quizData.subject}`,
        variant: "destructive",
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (questions.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one question",
        variant: "destructive",
      });
      return;
    }

    createQuizMutation.mutate({
      ...quizData,
      questions
    });
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Quiz Information */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Quiz Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="quiz-title">Quiz Title *</Label>
                <Input
                  id="quiz-title"
                  type="text"
                  placeholder="Enter quiz title"
                  value={quizData.title}
                  onChange={(e) => setQuizData(prev => ({ ...prev, title: e.target.value }))}
                  required
                  data-testid="input-quiz-title"
                />
              </div>
              
              <div>
                <Label htmlFor="duration">Duration (minutes)</Label>
                <Input
                  id="duration"
                  type="number"
                  min="1"
                  max="180"
                  placeholder="60"
                  value={quizData.duration}
                  onChange={(e) => setQuizData(prev => ({ ...prev, duration: parseInt(e.target.value) || 60 }))}
                  data-testid="input-duration"
                />
              </div>

              <div>
                <Label htmlFor="quiz-grade">Grade *</Label>
                <Select 
                  value={quizData.grade} 
                  onValueChange={(value) => setQuizData(prev => ({ ...prev, grade: value }))}
                >
                  <SelectTrigger data-testid="select-quiz-grade">
                    <SelectValue placeholder="Select grade" />
                  </SelectTrigger>
                  <SelectContent>
                    {grades.map((grade) => (
                      <SelectItem key={grade} value={grade}>
                        {grade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="quiz-subject">Subject *</Label>
                <Select 
                  value={quizData.subject} 
                  onValueChange={(value) => setQuizData(prev => ({ ...prev, subject: value }))}
                >
                  <SelectTrigger data-testid="select-quiz-subject">
                    <SelectValue placeholder="Select subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subject) => (
                      <SelectItem key={subject} value={subject}>
                        {subject}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="quiz-language">Language</Label>
                <Select 
                  value={quizData.language} 
                  onValueChange={(value) => setQuizData(prev => ({ ...prev, language: value }))}
                >
                  <SelectTrigger data-testid="select-quiz-language">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((language) => (
                      <SelectItem key={language} value={language}>
                        {language}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="quiz-description">Description</Label>
              <Textarea
                id="quiz-description"
                placeholder="Enter quiz description..."
                value={quizData.description}
                onChange={(e) => setQuizData(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
                data-testid="textarea-quiz-description"
              />
            </div>

            <div className="flex items-center justify-between">
              <Button
                type="button"
                variant="outline"
                onClick={generatePracticeQuestions}
                className="border-sa-blue text-sa-blue hover:bg-sa-blue hover:text-white"
                data-testid="button-generate-questions"
              >
                <BookOpen className="h-4 w-4 mr-2" />
                Generate Practice Questions
              </Button>
              
              <Badge variant="outline" className="flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                {quizData.duration} min
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Question Builder */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Add Questions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="question-text">Question</Label>
              <Textarea
                id="question-text"
                placeholder="Enter your question..."
                value={currentQuestion.question}
                onChange={(e) => setCurrentQuestion(prev => ({ ...prev, question: e.target.value }))}
                rows={2}
                data-testid="textarea-question"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentQuestion.options.map((option, index) => (
                <div key={index}>
                  <Label htmlFor={`option-${index}`}>Option {String.fromCharCode(65 + index)}</Label>
                  <Input
                    id={`option-${index}`}
                    type="text"
                    placeholder={`Enter option ${String.fromCharCode(65 + index)}`}
                    value={option}
                    onChange={(e) => {
                      const newOptions = [...currentQuestion.options];
                      newOptions[index] = e.target.value;
                      setCurrentQuestion(prev => ({ ...prev, options: newOptions }));
                    }}
                    data-testid={`input-option-${index}`}
                  />
                </div>
              ))}
            </div>

            <div>
              <Label htmlFor="correct-answer">Correct Answer</Label>
              <Select 
                value={currentQuestion.answer} 
                onValueChange={(value) => setCurrentQuestion(prev => ({ ...prev, answer: value }))}
              >
                <SelectTrigger data-testid="select-correct-answer">
                  <SelectValue placeholder="Select correct answer" />
                </SelectTrigger>
                <SelectContent>
                  {currentQuestion.options.map((option, index) => (
                    <SelectItem 
                      key={index} 
                      value={option}
                      disabled={!option}
                    >
                      {String.fromCharCode(65 + index)}: {option || 'Empty option'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              type="button"
              onClick={addQuestion}
              variant="outline"
              className="w-full border-sa-green text-sa-green hover:bg-sa-green hover:text-white"
              data-testid="button-add-question"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Question
            </Button>
          </CardContent>
        </Card>

        {/* Questions List */}
        {questions.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-gray-900">
                Quiz Questions ({questions.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {questions.map((question, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900 mb-2">
                          {index + 1}. {question.question}
                        </h4>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {question.options.map((option, optIndex) => (
                            <div 
                              key={optIndex} 
                              className={`p-2 rounded ${
                                option === question.answer 
                                  ? 'bg-sa-green/10 text-sa-green font-medium' 
                                  : 'bg-gray-100 text-gray-700'
                              }`}
                            >
                              {String.fromCharCode(65 + optIndex)}: {option}
                            </div>
                          ))}
                        </div>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeQuestion(index)}
                        className="text-sa-red hover:text-sa-red hover:bg-sa-red/10"
                        data-testid={`button-remove-question-${index}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={createQuizMutation.isPending || !quizData.title || !quizData.grade || !quizData.subject || questions.length === 0}
          className="w-full bg-sa-green hover:bg-sa-green-light text-white"
          data-testid="button-create-quiz"
        >
          {createQuizMutation.isPending ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Creating Quiz...
            </>
          ) : (
            <>
              <CheckCircle className="h-4 w-4 mr-2" />
              Create Quiz ({questions.length} questions)
            </>
          )}
        </Button>
      </form>
    </div>
  );
}
