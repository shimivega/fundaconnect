# Funda-App

## Overview

Funda-App is a comprehensive educational platform designed for South African learners, teachers, and ABET (Adult Basic Education and Training) adults. The application provides a centralized learning environment that supports all 11 official South African languages and offers interactive educational content, classroom management, and gamified learning experiences. The platform serves different user roles including administrators, teachers, and learners, each with specific functionalities tailored to their educational needs.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Monorepo Structure
The application follows a full-stack monorepo architecture with clear separation between client, server, and shared components:
- **Client**: React-based frontend using Vite as the build tool
- **Server**: Express.js backend with TypeScript
- **Shared**: Common schemas and types shared between frontend and backend

### Frontend Architecture
- **Framework**: React with TypeScript for type safety
- **UI Library**: shadcn/ui components built on top of Radix UI primitives
- **Styling**: TailwindCSS with custom South African flag-inspired color scheme
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite with React plugin and custom configurations

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Replit Auth integration with session-based authentication
- **File Uploads**: Multer middleware for handling PDF, video, and image uploads
- **Session Storage**: PostgreSQL-backed session storage using connect-pg-simple

### Database Design
The database schema includes:
- **Users**: Core user information with role-based access (admin, teacher, learner)
- **Classrooms**: Grade and subject-based classroom management
- **Content**: Educational materials (PDFs, videos, links) with metadata
- **Quizzes**: Quiz creation and management with multi-language support
- **Enrollments**: Many-to-many relationship between users and classrooms
- **Messages**: Communication system for classroom interactions
- **Notifications**: System-wide notification management

### Authentication and Authorization
- **Replit Auth**: Integrated OAuth system for user authentication
- **Role-based Access**: Three-tier permission system (admin, teacher, learner)
- **Session Management**: Secure session handling with PostgreSQL storage
- **Middleware Protection**: Route-level authentication checks

### Content Management
- **Multi-format Support**: PDFs, videos (YouTube integration), images, and external links
- **Grade and Subject Organization**: Content categorized by South African curriculum standards
- **Multi-language Support**: Content available in all 11 official South African languages
- **File Upload System**: Secure file handling with type validation and size limits

### Educational Features
- **Interactive Quizzes**: Multi-choice and short-answer questions with auto-grading
- **Practice Questions**: Curated question banks for different subjects and grades
- **Video Integration**: YouTube video embedding for educational content
- **Resource Links**: Curated links to South African educational resources
- **Gamification**: Quiz scoring, streaks, and achievement tracking

### UI/UX Design Patterns
- **Design System**: Consistent component library with South African theme
- **Responsive Design**: Mobile-first approach with Tailwind responsive utilities
- **Accessibility**: Radix UI primitives ensure ARIA compliance
- **Dark Mode**: Automatic theme switching capability
- **Component Architecture**: Reusable, composable UI components

## External Dependencies

### Core Framework Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity optimized for serverless environments
- **drizzle-orm**: Type-safe ORM for database operations with PostgreSQL dialect
- **@tanstack/react-query**: Server state management and caching
- **express**: Node.js web framework for API development
- **passport**: Authentication middleware for Express

### UI and Styling
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Type-safe variant API for component styling
- **lucide-react**: Icon library with React components

### Development and Build Tools
- **vite**: Fast build tool and development server
- **typescript**: Static type checking
- **@vitejs/plugin-react**: React support for Vite
- **esbuild**: Fast JavaScript bundler for production builds

### File Handling and Utilities
- **multer**: Multipart form data handling for file uploads
- **date-fns**: Date manipulation utilities
- **zod**: Runtime type validation and schema parsing
- **nanoid**: URL-safe unique ID generator

### Session and Security
- **connect-pg-simple**: PostgreSQL session store for Express
- **express-session**: Session middleware for Express
- **bcrypt**: Password hashing library
- **jsonwebtoken**: JWT token handling (if needed for API authentication)

### South African Educational Integration
- **Department of Basic Education Resources**: Integration points for official curriculum materials
- **Multi-language Support**: Language packs for all 11 official South African languages
- **CAPS Curriculum Alignment**: Content structured according to South African curriculum standards