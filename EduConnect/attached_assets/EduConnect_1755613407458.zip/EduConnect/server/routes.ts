import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import multer from "multer";
import path from "path";
import { 
  insertClassroomSchema,
  insertContentSchema,
  insertQuizSchema,
  insertNotificationSchema,
  insertMessageSchema,
  insertEnrollmentSchema
} from "@shared/schema";

// Configure multer for file uploads
const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const allowedTypes = ['.pdf', '.mp4', '.avi', '.mov', '.jpg', '.jpeg', '.png', '.gif'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Classroom routes
  app.get('/api/classrooms', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      let classrooms;
      if (user.role === 'teacher') {
        classrooms = await storage.getClassroomsByTeacher(userId);
      } else if (user.role === 'learner') {
        classrooms = await storage.getClassroomsByStudent(userId);
      } else {
        classrooms = await storage.getClassrooms();
      }
      
      res.json(classrooms);
    } catch (error) {
      console.error("Error fetching classrooms:", error);
      res.status(500).json({ message: "Failed to fetch classrooms" });
    }
  });

  app.post('/api/classrooms', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role !== 'teacher') {
        return res.status(403).json({ message: "Only teachers can create classrooms" });
      }

      const validatedData = insertClassroomSchema.parse({
        ...req.body,
        teacherId: userId
      });
      
      const classroom = await storage.createClassroom(validatedData);
      res.json(classroom);
    } catch (error) {
      console.error("Error creating classroom:", error);
      res.status(500).json({ message: "Failed to create classroom" });
    }
  });

  // Content routes
  app.get('/api/content', isAuthenticated, async (req: any, res) => {
    try {
      const { classroomId, grade, subject } = req.query;
      
      let content;
      if (classroomId) {
        content = await storage.getContentByClassroom(classroomId as string);
      } else if (grade && subject) {
        content = await storage.getContentByGradeAndSubject(grade as string, subject as string);
      } else {
        content = await storage.getContent();
      }
      
      res.json(content);
    } catch (error) {
      console.error("Error fetching content:", error);
      res.status(500).json({ message: "Failed to fetch content" });
    }
  });

  app.post('/api/content', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Only teachers and admins can upload content" });
      }

      let contentData;
      if (req.file) {
        // File upload
        const fileType = path.extname(req.file.originalname).toLowerCase();
        let type = 'pdf';
        if (['.mp4', '.avi', '.mov'].includes(fileType)) type = 'video';
        if (['.jpg', '.jpeg', '.png', '.gif'].includes(fileType)) type = 'image';

        contentData = {
          title: req.body.title || req.file.originalname,
          description: req.body.description || '',
          type,
          url: `/uploads/${req.file.filename}`,
          grade: req.body.grade,
          subject: req.body.subject,
          language: req.body.language || 'english',
          uploadedBy: userId,
          classroomId: req.body.classroomId || null,
          isApproved: user.role === 'admin'
        };
      } else {
        // YouTube video or link
        contentData = {
          title: req.body.title,
          description: req.body.description || '',
          type: req.body.type || 'youtube',
          url: req.body.url,
          grade: req.body.grade,
          subject: req.body.subject,
          language: req.body.language || 'english',
          uploadedBy: userId,
          classroomId: req.body.classroomId || null,
          isApproved: user.role === 'admin'
        };
      }

      const validatedData = insertContentSchema.parse(contentData);
      const content = await storage.createContent(validatedData);
      res.json(content);
    } catch (error) {
      console.error("Error uploading content:", error);
      res.status(500).json({ message: "Failed to upload content" });
    }
  });

  // Quiz routes
  app.get('/api/quizzes', isAuthenticated, async (req: any, res) => {
    try {
      const { classroomId } = req.query;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      let quizzes;
      if (classroomId) {
        quizzes = await storage.getQuizzesByClassroom(classroomId as string);
      } else if (user?.role === 'teacher') {
        quizzes = await storage.getQuizzesByTeacher(userId);
      } else {
        quizzes = await storage.getQuizzes();
      }
      
      res.json(quizzes);
    } catch (error) {
      console.error("Error fetching quizzes:", error);
      res.status(500).json({ message: "Failed to fetch quizzes" });
    }
  });

  app.post('/api/quizzes', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Only teachers and admins can create quizzes" });
      }

      const validatedData = insertQuizSchema.parse({
        ...req.body,
        createdBy: userId
      });
      
      const quiz = await storage.createQuiz(validatedData);
      res.json(quiz);
    } catch (error) {
      console.error("Error creating quiz:", error);
      res.status(500).json({ message: "Failed to create quiz" });
    }
  });

  // Quiz attempt routes
  app.post('/api/quiz-attempts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { quizId, answers } = req.body;
      
      const quiz = await storage.getQuizzes().then(quizzes => 
        quizzes.find(q => q.id === quizId)
      );
      
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }

      // Calculate score
      const questions = quiz.questions as any[];
      let score = 0;
      questions.forEach((q, index) => {
        if (answers[index] === q.answer) {
          score++;
        }
      });

      const attempt = await storage.createQuizAttempt({
        quizId,
        studentId: userId,
        answers,
        score,
        totalQuestions: questions.length,
        startedAt: new Date(),
        completedAt: new Date()
      });
      
      res.json(attempt);
    } catch (error) {
      console.error("Error submitting quiz attempt:", error);
      res.status(500).json({ message: "Failed to submit quiz attempt" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications = await storage.getNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || user.role === 'learner') {
        return res.status(403).json({ message: "Only teachers and admins can send notifications" });
      }

      const validatedData = insertNotificationSchema.parse({
        ...req.body,
        senderId: userId
      });
      
      const notification = await storage.createNotification(validatedData);
      res.json(notification);
    } catch (error) {
      console.error("Error creating notification:", error);
      res.status(500).json({ message: "Failed to create notification" });
    }
  });

  // Enrollment routes
  app.post('/api/enrollments', isAuthenticated, async (req: any, res) => {
    try {
      const { classroomId, studentId } = req.body;
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Allow self-enrollment for learners or teacher enrollment
      if (user?.role === 'learner' && studentId !== userId) {
        return res.status(403).json({ message: "Can only enroll yourself" });
      }

      const validatedData = insertEnrollmentSchema.parse({
        classroomId,
        studentId: studentId || userId
      });
      
      const enrollment = await storage.enrollStudent(validatedData);
      res.json(enrollment);
    } catch (error) {
      console.error("Error enrolling student:", error);
      res.status(500).json({ message: "Failed to enroll student" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    // Basic authentication for file access
    if (req.isAuthenticated && req.isAuthenticated()) {
      next();
    } else {
      res.status(401).json({ message: "Authentication required" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
