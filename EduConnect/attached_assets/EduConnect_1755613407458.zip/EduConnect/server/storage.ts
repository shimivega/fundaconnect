import {
  users,
  classrooms,
  content,
  quizzes,
  quizAttempts,
  notifications,
  messages,
  enrollments,
  type User,
  type UpsertUser,
  type Classroom,
  type InsertClassroom,
  type Content,
  type InsertContent,
  type Quiz,
  type InsertQuiz,
  type QuizAttempt,
  type Notification,
  type InsertNotification,
  type Message,
  type InsertMessage,
  type Enrollment,
  type InsertEnrollment,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Classroom operations
  getClassrooms(): Promise<Classroom[]>;
  getClassroomsByTeacher(teacherId: string): Promise<Classroom[]>;
  getClassroomsByStudent(studentId: string): Promise<Classroom[]>;
  createClassroom(classroom: InsertClassroom): Promise<Classroom>;
  updateClassroom(id: string, updates: Partial<InsertClassroom>): Promise<Classroom>;
  deleteClassroom(id: string): Promise<void>;
  
  // Content operations
  getContent(): Promise<Content[]>;
  getContentByClassroom(classroomId: string): Promise<Content[]>;
  getContentByGradeAndSubject(grade: string, subject: string): Promise<Content[]>;
  createContent(content: InsertContent): Promise<Content>;
  updateContent(id: string, updates: Partial<InsertContent>): Promise<Content>;
  deleteContent(id: string): Promise<void>;
  
  // Quiz operations
  getQuizzes(): Promise<Quiz[]>;
  getQuizzesByTeacher(teacherId: string): Promise<Quiz[]>;
  getQuizzesByClassroom(classroomId: string): Promise<Quiz[]>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  updateQuiz(id: string, updates: Partial<InsertQuiz>): Promise<Quiz>;
  deleteQuiz(id: string): Promise<void>;
  
  // Quiz attempt operations
  getQuizAttempts(quizId: string): Promise<QuizAttempt[]>;
  getStudentQuizAttempts(studentId: string): Promise<QuizAttempt[]>;
  createQuizAttempt(attempt: Omit<QuizAttempt, 'id'>): Promise<QuizAttempt>;
  updateQuizAttempt(id: string, updates: Partial<QuizAttempt>): Promise<QuizAttempt>;
  
  // Notification operations
  getNotifications(recipientId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationAsRead(id: string): Promise<void>;
  
  // Message operations
  getMessages(classroomId: string): Promise<Message[]>;
  getPrivateMessages(senderId: string, recipientId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Enrollment operations
  getEnrollments(classroomId: string): Promise<Enrollment[]>;
  enrollStudent(enrollment: InsertEnrollment): Promise<Enrollment>;
  unenrollStudent(classroomId: string, studentId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private classrooms: Map<string, Classroom> = new Map();
  private content: Map<string, Content> = new Map();
  private quizzes: Map<string, Quiz> = new Map();
  private quizAttempts: Map<string, QuizAttempt> = new Map();
  private notifications: Map<string, Notification> = new Map();
  private messages: Map<string, Message> = new Map();
  private enrollments: Map<string, Enrollment> = new Map();

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = Array.from(this.users.values()).find(u => u.id === userData.id);
    if (existingUser) {
      const updatedUser = { ...existingUser, ...userData, updatedAt: new Date() };
      this.users.set(existingUser.id, updatedUser);
      return updatedUser;
    } else {
      const newUser: User = {
        id: userData.id || randomUUID(),
        email: userData.email || null,
        firstName: userData.firstName || null,
        lastName: userData.lastName || null,
        profileImageUrl: userData.profileImageUrl || null,
        role: userData.role || 'learner',
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.users.set(newUser.id, newUser);
      return newUser;
    }
  }

  // Classroom operations
  async getClassrooms(): Promise<Classroom[]> {
    return Array.from(this.classrooms.values());
  }

  async getClassroomsByTeacher(teacherId: string): Promise<Classroom[]> {
    return Array.from(this.classrooms.values()).filter(c => c.teacherId === teacherId);
  }

  async getClassroomsByStudent(studentId: string): Promise<Classroom[]> {
    const enrolledClassroomIds = Array.from(this.enrollments.values())
      .filter(e => e.studentId === studentId)
      .map(e => e.classroomId);
    return Array.from(this.classrooms.values()).filter(c => 
      enrolledClassroomIds.includes(c.id)
    );
  }

  async createClassroom(classroomData: InsertClassroom): Promise<Classroom> {
    const classroom: Classroom = {
      id: randomUUID(),
      name: classroomData.name,
      grade: classroomData.grade,
      subject: classroomData.subject,
      teacherId: classroomData.teacherId,
      description: classroomData.description || null,
      isActive: classroomData.isActive ?? true,
      createdAt: new Date(),
    };
    this.classrooms.set(classroom.id, classroom);
    return classroom;
  }

  async updateClassroom(id: string, updates: Partial<InsertClassroom>): Promise<Classroom> {
    const existing = this.classrooms.get(id);
    if (!existing) throw new Error('Classroom not found');
    const updated = { ...existing, ...updates };
    this.classrooms.set(id, updated);
    return updated;
  }

  async deleteClassroom(id: string): Promise<void> {
    this.classrooms.delete(id);
  }

  // Content operations
  async getContent(): Promise<Content[]> {
    return Array.from(this.content.values());
  }

  async getContentByClassroom(classroomId: string): Promise<Content[]> {
    return Array.from(this.content.values()).filter(c => c.classroomId === classroomId);
  }

  async getContentByGradeAndSubject(grade: string, subject: string): Promise<Content[]> {
    return Array.from(this.content.values()).filter(c => 
      c.grade === grade && c.subject === subject
    );
  }

  async createContent(contentData: InsertContent): Promise<Content> {
    const content: Content = {
      id: randomUUID(),
      title: contentData.title,
      description: contentData.description || null,
      type: contentData.type,
      url: contentData.url,
      grade: contentData.grade || null,
      subject: contentData.subject || null,
      language: contentData.language || 'english',
      uploadedBy: contentData.uploadedBy,
      classroomId: contentData.classroomId || null,
      isApproved: contentData.isApproved ?? false,
      createdAt: new Date(),
    };
    this.content.set(content.id, content);
    return content;
  }

  async updateContent(id: string, updates: Partial<InsertContent>): Promise<Content> {
    const existing = this.content.get(id);
    if (!existing) throw new Error('Content not found');
    const updated = { ...existing, ...updates };
    this.content.set(id, updated);
    return updated;
  }

  async deleteContent(id: string): Promise<void> {
    this.content.delete(id);
  }

  // Quiz operations
  async getQuizzes(): Promise<Quiz[]> {
    return Array.from(this.quizzes.values());
  }

  async getQuizzesByTeacher(teacherId: string): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(q => q.createdBy === teacherId);
  }

  async getQuizzesByClassroom(classroomId: string): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter(q => q.classroomId === classroomId);
  }

  async createQuiz(quizData: InsertQuiz): Promise<Quiz> {
    const quiz: Quiz = {
      id: randomUUID(),
      title: quizData.title,
      description: quizData.description || null,
      grade: quizData.grade,
      subject: quizData.subject,
      language: quizData.language || 'english',
      questions: quizData.questions,
      duration: quizData.duration ?? 60,
      createdBy: quizData.createdBy,
      classroomId: quizData.classroomId || null,
      isScheduled: quizData.isScheduled ?? false,
      scheduledAt: quizData.scheduledAt || null,
      createdAt: new Date(),
    };
    this.quizzes.set(quiz.id, quiz);
    return quiz;
  }

  async updateQuiz(id: string, updates: Partial<InsertQuiz>): Promise<Quiz> {
    const existing = this.quizzes.get(id);
    if (!existing) throw new Error('Quiz not found');
    const updated = { ...existing, ...updates };
    this.quizzes.set(id, updated);
    return updated;
  }

  async deleteQuiz(id: string): Promise<void> {
    this.quizzes.delete(id);
  }

  // Quiz attempt operations
  async getQuizAttempts(quizId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values()).filter(qa => qa.quizId === quizId);
  }

  async getStudentQuizAttempts(studentId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values()).filter(qa => qa.studentId === studentId);
  }

  async createQuizAttempt(attemptData: Omit<QuizAttempt, 'id'>): Promise<QuizAttempt> {
    const attempt: QuizAttempt = {
      ...attemptData,
      id: randomUUID(),
    };
    this.quizAttempts.set(attempt.id, attempt);
    return attempt;
  }

  async updateQuizAttempt(id: string, updates: Partial<QuizAttempt>): Promise<QuizAttempt> {
    const existing = this.quizAttempts.get(id);
    if (!existing) throw new Error('Quiz attempt not found');
    const updated = { ...existing, ...updates };
    this.quizAttempts.set(id, updated);
    return updated;
  }

  // Notification operations
  async getNotifications(recipientId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(n => 
      n.recipientId === recipientId || !n.recipientId
    );
  }

  async createNotification(notificationData: InsertNotification): Promise<Notification> {
    const notification: Notification = {
      id: randomUUID(),
      title: notificationData.title,
      message: notificationData.message,
      type: notificationData.type,
      senderId: notificationData.senderId,
      recipientId: notificationData.recipientId || null,
      classroomId: notificationData.classroomId || null,
      isRead: notificationData.isRead ?? false,
      createdAt: new Date(),
    };
    this.notifications.set(notification.id, notification);
    return notification;
  }

  async markNotificationAsRead(id: string): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      this.notifications.set(id, { ...notification, isRead: true });
    }
  }

  // Message operations
  async getMessages(classroomId: string): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(m => m.classroomId === classroomId);
  }

  async getPrivateMessages(senderId: string, recipientId: string): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(m => 
      (m.senderId === senderId && m.recipientId === recipientId) ||
      (m.senderId === recipientId && m.recipientId === senderId)
    );
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const message: Message = {
      id: randomUUID(),
      content: messageData.content,
      senderId: messageData.senderId,
      classroomId: messageData.classroomId || null,
      recipientId: messageData.recipientId || null,
      createdAt: new Date(),
    };
    this.messages.set(message.id, message);
    return message;
  }

  // Enrollment operations
  async getEnrollments(classroomId: string): Promise<Enrollment[]> {
    return Array.from(this.enrollments.values()).filter(e => e.classroomId === classroomId);
  }

  async enrollStudent(enrollmentData: InsertEnrollment): Promise<Enrollment> {
    const enrollment: Enrollment = {
      ...enrollmentData,
      id: randomUUID(),
      enrolledAt: new Date(),
    };
    this.enrollments.set(enrollment.id, enrollment);
    return enrollment;
  }

  async unenrollStudent(classroomId: string, studentId: string): Promise<void> {
    const enrollment = Array.from(this.enrollments.values()).find(e => 
      e.classroomId === classroomId && e.studentId === studentId
    );
    if (enrollment) {
      this.enrollments.delete(enrollment.id);
    }
  }
}

export const storage = new MemStorage();
